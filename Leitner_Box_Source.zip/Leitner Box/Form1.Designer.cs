﻿namespace Leitner_Box
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Box 1");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Part 1", 2, 2);
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Part 2", 2, 2);
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Box 2", new System.Windows.Forms.TreeNode[] {
            treeNode2,
            treeNode3});
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Part 1", 2, 2);
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Part 2", 2, 2);
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Part 3", 2, 2);
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Part 4", 2, 2);
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Part 5", 2, 2);
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Box 3", new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode6,
            treeNode7,
            treeNode8,
            treeNode9});
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Part 1", 2, 2);
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Part 2", 2, 2);
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Part 3", 2, 2);
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Part 4", 2, 2);
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Part 5", 2, 2);
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Part 6", 2, 2);
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Part 7", 2, 2);
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Part 8", 2, 2);
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Box 4", new System.Windows.Forms.TreeNode[] {
            treeNode11,
            treeNode12,
            treeNode13,
            treeNode14,
            treeNode15,
            treeNode16,
            treeNode17,
            treeNode18});
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Part 1", 2, 2);
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Part 2", 2, 2);
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Part 3", 2, 2);
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Part 4", 2, 2);
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Part 5", 2, 2);
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Part 6", 2, 2);
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("Part 7", 2, 2);
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("Part 8", 2, 2);
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("Part 9", 2, 2);
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("Part 10", 2, 2);
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("Part 11", 2, 2);
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("Part 12", 2, 2);
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("Part 13", 2, 2);
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("Part 14", 2, 2);
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("Box 5", new System.Windows.Forms.TreeNode[] {
            treeNode20,
            treeNode21,
            treeNode22,
            treeNode23,
            treeNode24,
            treeNode25,
            treeNode26,
            treeNode27,
            treeNode28,
            treeNode29,
            treeNode30,
            treeNode31,
            treeNode32,
            treeNode33});
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("Data Base", 1, 1);
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportAllWordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optimizeXmlFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItemAboutMe = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.questionTextboxesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemRightToLeftQuestion = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemLeftToRightQuestion = new System.Windows.Forms.ToolStripMenuItem();
            this.answerTextboxesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemRightToLeftAnswer = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemLeftToRightAnswer = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.dateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemChristianDate = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemPersianDate = new System.Windows.Forms.ToolStripMenuItem();
            this.usersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemCreateNewUser = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemSelectUser = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageAddQuestions = new System.Windows.Forms.TabPage();
            this.listBoxAutoComplete = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.labelPartID = new System.Windows.Forms.Label();
            this.labelBoxID = new System.Windows.Forms.Label();
            this.labelNewWordDate = new System.Windows.Forms.Label();
            this.labelAddQuestionMessage = new System.Windows.Forms.Label();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxNewAnswer = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxNewQuestion = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPageExplorer = new System.Windows.Forms.TabPage();
            this.labelAnswerToQuestionMessage = new System.Windows.Forms.Label();
            this.buttonDelete1 = new System.Windows.Forms.Button();
            this.buttonSave1 = new System.Windows.Forms.Button();
            this.buttonFalse = new System.Windows.Forms.Button();
            this.buttonTrue = new System.Windows.Forms.Button();
            this.buttonShowAnswer = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxAnswer = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxQuestion = new System.Windows.Forms.TextBox();
            this.labelRegDate = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3Box1 = new System.Windows.Forms.Label();
            this.label2WordsCount = new System.Windows.Forms.Label();
            this.label1Box1 = new System.Windows.Forms.Label();
            this.tabPageSearch = new System.Windows.Forms.TabPage();
            this.checkBoxSearchInAnswer = new System.Windows.Forms.CheckBox();
            this.checkBoxSearchInQuestion = new System.Windows.Forms.CheckBox();
            this.labelSearchMessage = new System.Windows.Forms.Label();
            this.buttonSearchMoveToBox1 = new System.Windows.Forms.Button();
            this.buttonSearchSave = new System.Windows.Forms.Button();
            this.buttonSearchDelete = new System.Windows.Forms.Button();
            this.textBoxSearchAnswer = new System.Windows.Forms.TextBox();
            this.textBoxSearchQuestion = new System.Windows.Forms.TextBox();
            this.label1Search = new System.Windows.Forms.Label();
            this.listViewSearch = new System.Windows.Forms.ListView();
            this.QuestionColumn = new System.Windows.Forms.ColumnHeader();
            this.AnswerColumn = new System.Windows.Forms.ColumnHeader();
            this.DateColumn = new System.Windows.Forms.ColumnHeader();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.tabPageStatistics = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.labelAllWords = new System.Windows.Forms.Label();
            this.label20Statistics = new System.Windows.Forms.Label();
            this.labelStatisticsDate = new System.Windows.Forms.Label();
            this.label19Statistics = new System.Windows.Forms.Label();
            this.label18Statistics = new System.Windows.Forms.Label();
            this.labelStatisticsDataBase = new System.Windows.Forms.Label();
            this.label16Statistics = new System.Windows.Forms.Label();
            this.label15Statistics = new System.Windows.Forms.Label();
            this.labelStatisticsBox5 = new System.Windows.Forms.Label();
            this.label13Statistics = new System.Windows.Forms.Label();
            this.label12Statistics = new System.Windows.Forms.Label();
            this.labelStatisticsBox4 = new System.Windows.Forms.Label();
            this.label10Statistics = new System.Windows.Forms.Label();
            this.label9Statistics = new System.Windows.Forms.Label();
            this.labelStatisticsBox3 = new System.Windows.Forms.Label();
            this.label7Statistics = new System.Windows.Forms.Label();
            this.label6Statistics = new System.Windows.Forms.Label();
            this.labelStatisticsBox2 = new System.Windows.Forms.Label();
            this.label4Statistics = new System.Windows.Forms.Label();
            this.label3Statistics = new System.Windows.Forms.Label();
            this.labelStatisticsBox1 = new System.Windows.Forms.Label();
            this.label1Statistics = new System.Windows.Forms.Label();
            this.columnHeaderQuestion = new System.Windows.Forms.ColumnHeader();
            this.columnHeaderAnswer = new System.Windows.Forms.ColumnHeader();
            this.columnHeaderDate = new System.Windows.Forms.ColumnHeader();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ToolStripMenuItemDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItemShiftUp = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItemMoveTo = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox2Part1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox2Part2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox3 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox3Part1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox3Part2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox3Part3 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox3Part4 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox3Part5 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox4 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox4Part1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox4Part2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox4Part3 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox4Part4 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox4Part5 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox4Part6 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox4Part7 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox4Part8 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part3 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part4 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part5 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part6 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part7 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part8 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part9 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part10 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part11 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part12 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part13 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBox5Part14 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemDataBase = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemExport = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPageAddQuestions.SuspendLayout();
            this.tabPageExplorer.SuspendLayout();
            this.tabPageSearch.SuspendLayout();
            this.tabPageStatistics.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.SystemColors.Control;
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treeView1);
            this.splitContainer1.Panel1MinSize = 180;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tableLayoutPanel1);
            this.splitContainer1.Panel2MinSize = 140;
            this.splitContainer1.Size = new System.Drawing.Size(881, 643);
            this.splitContainer1.SplitterDistance = 242;
            this.splitContainer1.SplitterWidth = 10;
            this.splitContainer1.TabIndex = 0;
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.ForeColor = System.Drawing.Color.Black;
            this.treeView1.HideSelection = false;
            this.treeView1.ImageIndex = 0;
            this.treeView1.ImageList = this.imageList1;
            this.treeView1.Indent = 27;
            this.treeView1.ItemHeight = 40;
            this.treeView1.Location = new System.Drawing.Point(0, 0);
            this.treeView1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.treeView1.Name = "treeView1";
            treeNode1.Name = "Box1";
            treeNode1.Text = "Box 1";
            treeNode2.ImageIndex = 2;
            treeNode2.Name = "Box2Part1";
            treeNode2.SelectedImageIndex = 2;
            treeNode2.Text = "Part 1";
            treeNode3.ImageIndex = 2;
            treeNode3.Name = "Box2Part2";
            treeNode3.SelectedImageIndex = 2;
            treeNode3.Text = "Part 2";
            treeNode4.Name = "Box2";
            treeNode4.Text = "Box 2";
            treeNode5.ImageIndex = 2;
            treeNode5.Name = "Box3Part1";
            treeNode5.SelectedImageIndex = 2;
            treeNode5.Text = "Part 1";
            treeNode6.ImageIndex = 2;
            treeNode6.Name = "Box3Part2";
            treeNode6.SelectedImageIndex = 2;
            treeNode6.Text = "Part 2";
            treeNode7.ImageIndex = 2;
            treeNode7.Name = "Box3Part3";
            treeNode7.SelectedImageIndex = 2;
            treeNode7.Text = "Part 3";
            treeNode8.ImageIndex = 2;
            treeNode8.Name = "Box3Part4";
            treeNode8.SelectedImageIndex = 2;
            treeNode8.Text = "Part 4";
            treeNode9.ImageIndex = 2;
            treeNode9.Name = "Box3Part5";
            treeNode9.SelectedImageIndex = 2;
            treeNode9.Text = "Part 5";
            treeNode10.Name = "Box3";
            treeNode10.Text = "Box 3";
            treeNode11.ImageIndex = 2;
            treeNode11.Name = "Box4Part1";
            treeNode11.SelectedImageIndex = 2;
            treeNode11.Text = "Part 1";
            treeNode12.ImageIndex = 2;
            treeNode12.Name = "Box4Part2";
            treeNode12.SelectedImageIndex = 2;
            treeNode12.Text = "Part 2";
            treeNode13.ImageIndex = 2;
            treeNode13.Name = "Box4Part3";
            treeNode13.SelectedImageIndex = 2;
            treeNode13.Text = "Part 3";
            treeNode14.ImageIndex = 2;
            treeNode14.Name = "Box4Part4";
            treeNode14.SelectedImageIndex = 2;
            treeNode14.Text = "Part 4";
            treeNode15.ImageIndex = 2;
            treeNode15.Name = "Box4Part5";
            treeNode15.SelectedImageIndex = 2;
            treeNode15.Text = "Part 5";
            treeNode16.ImageIndex = 2;
            treeNode16.Name = "Box4Part6";
            treeNode16.SelectedImageIndex = 2;
            treeNode16.Text = "Part 6";
            treeNode17.ImageIndex = 2;
            treeNode17.Name = "Box4Part7";
            treeNode17.SelectedImageIndex = 2;
            treeNode17.Text = "Part 7";
            treeNode18.ImageIndex = 2;
            treeNode18.Name = "Box4Part8";
            treeNode18.SelectedImageIndex = 2;
            treeNode18.Text = "Part 8";
            treeNode19.Name = "Box4";
            treeNode19.Text = "Box 4";
            treeNode20.ImageIndex = 2;
            treeNode20.Name = "Box5Part1";
            treeNode20.SelectedImageIndex = 2;
            treeNode20.Text = "Part 1";
            treeNode21.ImageIndex = 2;
            treeNode21.Name = "Box5Part2";
            treeNode21.SelectedImageIndex = 2;
            treeNode21.Text = "Part 2";
            treeNode22.ImageIndex = 2;
            treeNode22.Name = "Box5Part3";
            treeNode22.SelectedImageIndex = 2;
            treeNode22.Text = "Part 3";
            treeNode23.ImageIndex = 2;
            treeNode23.Name = "Box5Part4";
            treeNode23.SelectedImageIndex = 2;
            treeNode23.Text = "Part 4";
            treeNode24.ImageIndex = 2;
            treeNode24.Name = "Box5Part5";
            treeNode24.SelectedImageIndex = 2;
            treeNode24.Text = "Part 5";
            treeNode25.ImageIndex = 2;
            treeNode25.Name = "Box5Part6";
            treeNode25.SelectedImageIndex = 2;
            treeNode25.Text = "Part 6";
            treeNode26.ImageIndex = 2;
            treeNode26.Name = "Box5Part7";
            treeNode26.SelectedImageIndex = 2;
            treeNode26.Text = "Part 7";
            treeNode27.ImageIndex = 2;
            treeNode27.Name = "Box5Part8";
            treeNode27.SelectedImageIndex = 2;
            treeNode27.Text = "Part 8";
            treeNode28.ImageIndex = 2;
            treeNode28.Name = "Box5Part9";
            treeNode28.SelectedImageIndex = 2;
            treeNode28.Text = "Part 9";
            treeNode29.ImageIndex = 2;
            treeNode29.Name = "Box5Part10";
            treeNode29.SelectedImageIndex = 2;
            treeNode29.Text = "Part 10";
            treeNode30.ImageIndex = 2;
            treeNode30.Name = "Box5Part11";
            treeNode30.SelectedImageIndex = 2;
            treeNode30.Text = "Part 11";
            treeNode31.ImageIndex = 2;
            treeNode31.Name = "Box5Part12";
            treeNode31.SelectedImageIndex = 2;
            treeNode31.Text = "Part 12";
            treeNode32.ImageIndex = 2;
            treeNode32.Name = "Box5Part13";
            treeNode32.SelectedImageIndex = 2;
            treeNode32.Text = "Part 13";
            treeNode33.ImageIndex = 2;
            treeNode33.Name = "Box5Part14";
            treeNode33.SelectedImageIndex = 2;
            treeNode33.Text = "Part 14";
            treeNode34.Name = "Box5";
            treeNode34.Text = "Box 5";
            treeNode35.ImageIndex = 1;
            treeNode35.Name = "DataBase";
            treeNode35.SelectedImageIndex = 1;
            treeNode35.Text = "Data Base";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode4,
            treeNode10,
            treeNode19,
            treeNode34,
            treeNode35});
            this.treeView1.SelectedImageIndex = 0;
            this.treeView1.Size = new System.Drawing.Size(238, 639);
            this.treeView1.TabIndex = 1;
            this.treeView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.treeView1_MouseClick);
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Box.ico");
            this.imageList1.Images.SetKeyName(1, "database.ico");
            this.imageList1.Images.SetKeyName(2, "My Documents.ico");
            this.imageList1.Images.SetKeyName(3, "kcmfontinst.ico");
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tabControl1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.650831F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 93.34917F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(625, 639);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.settingToolStripMenuItem,
            this.usersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(6, 3, 0, 3);
            this.menuStrip1.Size = new System.Drawing.Size(625, 42);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportAllWordsToolStripMenuItem,
            this.optimizeXmlFileToolStripMenuItem,
            this.toolStripSeparator4,
            this.ToolStripMenuItemAboutMe,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 36);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exportAllWordsToolStripMenuItem
            // 
            this.exportAllWordsToolStripMenuItem.Name = "exportAllWordsToolStripMenuItem";
            this.exportAllWordsToolStripMenuItem.Size = new System.Drawing.Size(192, 24);
            this.exportAllWordsToolStripMenuItem.Text = "Export all words";
            this.exportAllWordsToolStripMenuItem.Click += new System.EventHandler(this.exportAllWordsToolStripMenuItem_Click);
            // 
            // optimizeXmlFileToolStripMenuItem
            // 
            this.optimizeXmlFileToolStripMenuItem.Name = "optimizeXmlFileToolStripMenuItem";
            this.optimizeXmlFileToolStripMenuItem.Size = new System.Drawing.Size(192, 24);
            this.optimizeXmlFileToolStripMenuItem.Text = "Optimize xml file";
            this.optimizeXmlFileToolStripMenuItem.Click += new System.EventHandler(this.optimizeXmlFileToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(189, 6);
            // 
            // ToolStripMenuItemAboutMe
            // 
            this.ToolStripMenuItemAboutMe.Name = "ToolStripMenuItemAboutMe";
            this.ToolStripMenuItemAboutMe.Size = new System.Drawing.Size(192, 24);
            this.ToolStripMenuItemAboutMe.Text = "About me";
            this.ToolStripMenuItemAboutMe.Click += new System.EventHandler(this.ToolStripMenuItemAboutMe_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(192, 24);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // settingToolStripMenuItem
            // 
            this.settingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.questionTextboxesToolStripMenuItem,
            this.answerTextboxesToolStripMenuItem,
            this.toolStripSeparator1,
            this.dateToolStripMenuItem});
            this.settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            this.settingToolStripMenuItem.Size = new System.Drawing.Size(68, 36);
            this.settingToolStripMenuItem.Text = "Setting";
            // 
            // questionTextboxesToolStripMenuItem
            // 
            this.questionTextboxesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemRightToLeftQuestion,
            this.ToolStripMenuItemLeftToRightQuestion});
            this.questionTextboxesToolStripMenuItem.Name = "questionTextboxesToolStripMenuItem";
            this.questionTextboxesToolStripMenuItem.Size = new System.Drawing.Size(208, 24);
            this.questionTextboxesToolStripMenuItem.Text = "Question Textboxes";
            // 
            // ToolStripMenuItemRightToLeftQuestion
            // 
            this.ToolStripMenuItemRightToLeftQuestion.Name = "ToolStripMenuItemRightToLeftQuestion";
            this.ToolStripMenuItemRightToLeftQuestion.Size = new System.Drawing.Size(163, 24);
            this.ToolStripMenuItemRightToLeftQuestion.Text = "Right To Left";
            this.ToolStripMenuItemRightToLeftQuestion.Click += new System.EventHandler(this.ToolStripMenuItemRightToLeftQuestion_Click);
            // 
            // ToolStripMenuItemLeftToRightQuestion
            // 
            this.ToolStripMenuItemLeftToRightQuestion.Name = "ToolStripMenuItemLeftToRightQuestion";
            this.ToolStripMenuItemLeftToRightQuestion.Size = new System.Drawing.Size(163, 24);
            this.ToolStripMenuItemLeftToRightQuestion.Text = "Left To Right";
            this.ToolStripMenuItemLeftToRightQuestion.Click += new System.EventHandler(this.ToolStripMenuItemLeftToRightQuestion_Click);
            // 
            // answerTextboxesToolStripMenuItem
            // 
            this.answerTextboxesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemRightToLeftAnswer,
            this.ToolStripMenuItemLeftToRightAnswer});
            this.answerTextboxesToolStripMenuItem.Name = "answerTextboxesToolStripMenuItem";
            this.answerTextboxesToolStripMenuItem.Size = new System.Drawing.Size(208, 24);
            this.answerTextboxesToolStripMenuItem.Text = "Answer Textboxes";
            // 
            // ToolStripMenuItemRightToLeftAnswer
            // 
            this.ToolStripMenuItemRightToLeftAnswer.Name = "ToolStripMenuItemRightToLeftAnswer";
            this.ToolStripMenuItemRightToLeftAnswer.Size = new System.Drawing.Size(163, 24);
            this.ToolStripMenuItemRightToLeftAnswer.Text = "Right To Left";
            this.ToolStripMenuItemRightToLeftAnswer.Click += new System.EventHandler(this.ToolStripMenuItemRightToLeftAnswer_Click);
            // 
            // ToolStripMenuItemLeftToRightAnswer
            // 
            this.ToolStripMenuItemLeftToRightAnswer.Name = "ToolStripMenuItemLeftToRightAnswer";
            this.ToolStripMenuItemLeftToRightAnswer.Size = new System.Drawing.Size(163, 24);
            this.ToolStripMenuItemLeftToRightAnswer.Text = "Left To Right";
            this.ToolStripMenuItemLeftToRightAnswer.Click += new System.EventHandler(this.ToolStripMenuItemLeftToRightAnswer_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(205, 6);
            // 
            // dateToolStripMenuItem
            // 
            this.dateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemChristianDate,
            this.ToolStripMenuItemPersianDate});
            this.dateToolStripMenuItem.Name = "dateToolStripMenuItem";
            this.dateToolStripMenuItem.Size = new System.Drawing.Size(208, 24);
            this.dateToolStripMenuItem.Text = "Date";
            // 
            // ToolStripMenuItemChristianDate
            // 
            this.ToolStripMenuItemChristianDate.Name = "ToolStripMenuItemChristianDate";
            this.ToolStripMenuItemChristianDate.Size = new System.Drawing.Size(135, 24);
            this.ToolStripMenuItemChristianDate.Text = "Christian";
            this.ToolStripMenuItemChristianDate.Click += new System.EventHandler(this.ToolStripMenuItemChristianDate_Click);
            // 
            // ToolStripMenuItemPersianDate
            // 
            this.ToolStripMenuItemPersianDate.Name = "ToolStripMenuItemPersianDate";
            this.ToolStripMenuItemPersianDate.Size = new System.Drawing.Size(135, 24);
            this.ToolStripMenuItemPersianDate.Text = "Persian";
            this.ToolStripMenuItemPersianDate.Click += new System.EventHandler(this.ToolStripMenuItemPersianDate_Click);
            // 
            // usersToolStripMenuItem
            // 
            this.usersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemCreateNewUser,
            this.ToolStripMenuItemSelectUser});
            this.usersToolStripMenuItem.Name = "usersToolStripMenuItem";
            this.usersToolStripMenuItem.Size = new System.Drawing.Size(56, 36);
            this.usersToolStripMenuItem.Text = "Users";
            // 
            // ToolStripMenuItemCreateNewUser
            // 
            this.ToolStripMenuItemCreateNewUser.Name = "ToolStripMenuItemCreateNewUser";
            this.ToolStripMenuItemCreateNewUser.Size = new System.Drawing.Size(151, 24);
            this.ToolStripMenuItemCreateNewUser.Text = "New User";
            this.ToolStripMenuItemCreateNewUser.Click += new System.EventHandler(this.ToolStripMenuItemCreateNewUser_Click);
            // 
            // ToolStripMenuItemSelectUser
            // 
            this.ToolStripMenuItemSelectUser.Name = "ToolStripMenuItemSelectUser";
            this.ToolStripMenuItemSelectUser.Size = new System.Drawing.Size(151, 24);
            this.ToolStripMenuItemSelectUser.Text = "Select User";
            this.ToolStripMenuItemSelectUser.Click += new System.EventHandler(this.ToolStripMenuItemSelectUser_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageAddQuestions);
            this.tabControl1.Controls.Add(this.tabPageExplorer);
            this.tabControl1.Controls.Add(this.tabPageSearch);
            this.tabControl1.Controls.Add(this.tabPageStatistics);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(5, 47);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(615, 587);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPageAddQuestions
            // 
            this.tabPageAddQuestions.Controls.Add(this.listBoxAutoComplete);
            this.tabPageAddQuestions.Controls.Add(this.label6);
            this.tabPageAddQuestions.Controls.Add(this.labelPartID);
            this.tabPageAddQuestions.Controls.Add(this.labelBoxID);
            this.tabPageAddQuestions.Controls.Add(this.labelNewWordDate);
            this.tabPageAddQuestions.Controls.Add(this.labelAddQuestionMessage);
            this.tabPageAddQuestions.Controls.Add(this.buttonAdd);
            this.tabPageAddQuestions.Controls.Add(this.label5);
            this.tabPageAddQuestions.Controls.Add(this.label4);
            this.tabPageAddQuestions.Controls.Add(this.textBoxNewAnswer);
            this.tabPageAddQuestions.Controls.Add(this.label3);
            this.tabPageAddQuestions.Controls.Add(this.textBoxNewQuestion);
            this.tabPageAddQuestions.Controls.Add(this.label2);
            this.tabPageAddQuestions.Controls.Add(this.label1);
            this.tabPageAddQuestions.Location = new System.Drawing.Point(4, 29);
            this.tabPageAddQuestions.Margin = new System.Windows.Forms.Padding(5);
            this.tabPageAddQuestions.Name = "tabPageAddQuestions";
            this.tabPageAddQuestions.Padding = new System.Windows.Forms.Padding(5);
            this.tabPageAddQuestions.Size = new System.Drawing.Size(607, 554);
            this.tabPageAddQuestions.TabIndex = 0;
            this.tabPageAddQuestions.Text = "Add Questions";
            this.tabPageAddQuestions.UseVisualStyleBackColor = true;
            this.tabPageAddQuestions.Enter += new System.EventHandler(this.tabPageInsertWord_Enter);
            // 
            // listBoxAutoComplete
            // 
            this.listBoxAutoComplete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(216)))));
            this.listBoxAutoComplete.ForeColor = System.Drawing.Color.DimGray;
            this.listBoxAutoComplete.FormattingEnabled = true;
            this.listBoxAutoComplete.HorizontalScrollbar = true;
            this.listBoxAutoComplete.ItemHeight = 20;
            this.listBoxAutoComplete.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06"});
            this.listBoxAutoComplete.Location = new System.Drawing.Point(107, 218);
            this.listBoxAutoComplete.Margin = new System.Windows.Forms.Padding(5);
            this.listBoxAutoComplete.Name = "listBoxAutoComplete";
            this.listBoxAutoComplete.Size = new System.Drawing.Size(435, 164);
            this.listBoxAutoComplete.Sorted = true;
            this.listBoxAutoComplete.TabIndex = 0;
            this.listBoxAutoComplete.Visible = false;
            this.listBoxAutoComplete.DoubleClick += new System.EventHandler(this.listBoxAutoComplete_DoubleClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(103, 80);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(166, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Insert the question in :";
            // 
            // labelPartID
            // 
            this.labelPartID.AutoSize = true;
            this.labelPartID.ForeColor = System.Drawing.Color.Red;
            this.labelPartID.Location = new System.Drawing.Point(426, 105);
            this.labelPartID.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelPartID.Name = "labelPartID";
            this.labelPartID.Size = new System.Drawing.Size(27, 20);
            this.labelPartID.TabIndex = 0;
            this.labelPartID.Text = "00";
            // 
            // labelBoxID
            // 
            this.labelBoxID.AutoSize = true;
            this.labelBoxID.ForeColor = System.Drawing.Color.Red;
            this.labelBoxID.Location = new System.Drawing.Point(395, 80);
            this.labelBoxID.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelBoxID.Name = "labelBoxID";
            this.labelBoxID.Size = new System.Drawing.Size(27, 20);
            this.labelBoxID.TabIndex = 0;
            this.labelBoxID.Text = "00";
            // 
            // labelNewWordDate
            // 
            this.labelNewWordDate.AutoSize = true;
            this.labelNewWordDate.Location = new System.Drawing.Point(234, 33);
            this.labelNewWordDate.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelNewWordDate.Name = "labelNewWordDate";
            this.labelNewWordDate.Size = new System.Drawing.Size(87, 20);
            this.labelNewWordDate.TabIndex = 0;
            this.labelNewWordDate.Text = "00 / 00 / 00";
            // 
            // labelAddQuestionMessage
            // 
            this.labelAddQuestionMessage.AutoSize = true;
            this.labelAddQuestionMessage.ForeColor = System.Drawing.Color.Green;
            this.labelAddQuestionMessage.Location = new System.Drawing.Point(10, 519);
            this.labelAddQuestionMessage.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelAddQuestionMessage.Name = "labelAddQuestionMessage";
            this.labelAddQuestionMessage.Size = new System.Drawing.Size(51, 20);
            this.labelAddQuestionMessage.TabIndex = 0;
            this.labelAddQuestionMessage.Text = "label1";
            // 
            // buttonAdd
            // 
            this.buttonAdd.Location = new System.Drawing.Point(204, 466);
            this.buttonAdd.Margin = new System.Windows.Forms.Padding(5);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(180, 45);
            this.buttonAdd.TabIndex = 3;
            this.buttonAdd.Text = "Add";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAddNewWord_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(157, 33);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Now : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 362);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Answer :";
            // 
            // textBoxNewAnswer
            // 
            this.textBoxNewAnswer.AcceptsReturn = true;
            this.textBoxNewAnswer.AutoCompleteCustomSource.AddRange(new string[] {
            "01",
            "02",
            "03",
            "04",
            "05"});
            this.textBoxNewAnswer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.textBoxNewAnswer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBoxNewAnswer.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNewAnswer.Location = new System.Drawing.Point(108, 318);
            this.textBoxNewAnswer.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxNewAnswer.Multiline = true;
            this.textBoxNewAnswer.Name = "textBoxNewAnswer";
            this.textBoxNewAnswer.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxNewAnswer.Size = new System.Drawing.Size(435, 126);
            this.textBoxNewAnswer.TabIndex = 2;
            this.textBoxNewAnswer.TextChanged += new System.EventHandler(this.textBoxNewAnswer_TextChanged);
            this.textBoxNewAnswer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxKeyDown);
            this.textBoxNewAnswer.Leave += new System.EventHandler(this.textBoxNewQuestion_Or_NewAnswer_Leave);
            this.textBoxNewAnswer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            this.textBoxNewAnswer.Enter += new System.EventHandler(this.textBox_Enter);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 226);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Question :";
            // 
            // textBoxNewQuestion
            // 
            this.textBoxNewQuestion.AcceptsReturn = true;
            this.textBoxNewQuestion.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNewQuestion.Location = new System.Drawing.Point(108, 167);
            this.textBoxNewQuestion.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxNewQuestion.Multiline = true;
            this.textBoxNewQuestion.Name = "textBoxNewQuestion";
            this.textBoxNewQuestion.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxNewQuestion.Size = new System.Drawing.Size(435, 126);
            this.textBoxNewQuestion.TabIndex = 1;
            this.textBoxNewQuestion.TextChanged += new System.EventHandler(this.textBoxNewQuestion_TextChanged);
            this.textBoxNewQuestion.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxKeyDown);
            this.textBoxNewQuestion.Leave += new System.EventHandler(this.textBoxNewQuestion_Or_NewAnswer_Leave);
            this.textBoxNewQuestion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            this.textBoxNewQuestion.Enter += new System.EventHandler(this.textBox_Enter);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(354, 105);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Part :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(328, 80);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Box :";
            // 
            // tabPageExplorer
            // 
            this.tabPageExplorer.Controls.Add(this.labelAnswerToQuestionMessage);
            this.tabPageExplorer.Controls.Add(this.buttonDelete1);
            this.tabPageExplorer.Controls.Add(this.buttonSave1);
            this.tabPageExplorer.Controls.Add(this.buttonFalse);
            this.tabPageExplorer.Controls.Add(this.buttonTrue);
            this.tabPageExplorer.Controls.Add(this.buttonShowAnswer);
            this.tabPageExplorer.Controls.Add(this.label8);
            this.tabPageExplorer.Controls.Add(this.textBoxAnswer);
            this.tabPageExplorer.Controls.Add(this.label9);
            this.tabPageExplorer.Controls.Add(this.textBoxQuestion);
            this.tabPageExplorer.Controls.Add(this.labelRegDate);
            this.tabPageExplorer.Controls.Add(this.label7);
            this.tabPageExplorer.Controls.Add(this.label3Box1);
            this.tabPageExplorer.Controls.Add(this.label2WordsCount);
            this.tabPageExplorer.Controls.Add(this.label1Box1);
            this.tabPageExplorer.Location = new System.Drawing.Point(4, 29);
            this.tabPageExplorer.Margin = new System.Windows.Forms.Padding(5);
            this.tabPageExplorer.Name = "tabPageExplorer";
            this.tabPageExplorer.Padding = new System.Windows.Forms.Padding(5);
            this.tabPageExplorer.Size = new System.Drawing.Size(607, 554);
            this.tabPageExplorer.TabIndex = 1;
            this.tabPageExplorer.Text = "Answer to Questions";
            this.tabPageExplorer.UseVisualStyleBackColor = true;
            this.tabPageExplorer.Enter += new System.EventHandler(this.tabPageExplorer_Enter);
            // 
            // labelAnswerToQuestionMessage
            // 
            this.labelAnswerToQuestionMessage.AutoSize = true;
            this.labelAnswerToQuestionMessage.ForeColor = System.Drawing.Color.Green;
            this.labelAnswerToQuestionMessage.Location = new System.Drawing.Point(10, 517);
            this.labelAnswerToQuestionMessage.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelAnswerToQuestionMessage.Name = "labelAnswerToQuestionMessage";
            this.labelAnswerToQuestionMessage.Size = new System.Drawing.Size(51, 20);
            this.labelAnswerToQuestionMessage.TabIndex = 21;
            this.labelAnswerToQuestionMessage.Text = "label1";
            // 
            // buttonDelete1
            // 
            this.buttonDelete1.Enabled = false;
            this.buttonDelete1.Location = new System.Drawing.Point(351, 461);
            this.buttonDelete1.Margin = new System.Windows.Forms.Padding(5);
            this.buttonDelete1.Name = "buttonDelete1";
            this.buttonDelete1.Size = new System.Drawing.Size(121, 45);
            this.buttonDelete1.TabIndex = 20;
            this.buttonDelete1.Text = "Delete";
            this.buttonDelete1.UseVisualStyleBackColor = true;
            this.buttonDelete1.Click += new System.EventHandler(this.buttonDelete1_Click);
            // 
            // buttonSave1
            // 
            this.buttonSave1.Enabled = false;
            this.buttonSave1.Location = new System.Drawing.Point(105, 461);
            this.buttonSave1.Margin = new System.Windows.Forms.Padding(5);
            this.buttonSave1.Name = "buttonSave1";
            this.buttonSave1.Size = new System.Drawing.Size(121, 45);
            this.buttonSave1.TabIndex = 19;
            this.buttonSave1.Text = "Save";
            this.buttonSave1.UseVisualStyleBackColor = true;
            this.buttonSave1.Click += new System.EventHandler(this.buttonSave1_Click);
            // 
            // buttonFalse
            // 
            this.buttonFalse.Enabled = false;
            this.buttonFalse.Location = new System.Drawing.Point(447, 395);
            this.buttonFalse.Margin = new System.Windows.Forms.Padding(5);
            this.buttonFalse.Name = "buttonFalse";
            this.buttonFalse.Size = new System.Drawing.Size(121, 49);
            this.buttonFalse.TabIndex = 14;
            this.buttonFalse.Text = "False";
            this.buttonFalse.UseVisualStyleBackColor = true;
            this.buttonFalse.Click += new System.EventHandler(this.buttonFalse_Click);
            // 
            // buttonTrue
            // 
            this.buttonTrue.Enabled = false;
            this.buttonTrue.Location = new System.Drawing.Point(38, 395);
            this.buttonTrue.Margin = new System.Windows.Forms.Padding(5);
            this.buttonTrue.Name = "buttonTrue";
            this.buttonTrue.Size = new System.Drawing.Size(114, 49);
            this.buttonTrue.TabIndex = 13;
            this.buttonTrue.Text = "True";
            this.buttonTrue.UseVisualStyleBackColor = true;
            this.buttonTrue.Click += new System.EventHandler(this.buttonTrue_Click);
            // 
            // buttonShowAnswer
            // 
            this.buttonShowAnswer.Enabled = false;
            this.buttonShowAnswer.Location = new System.Drawing.Point(195, 395);
            this.buttonShowAnswer.Margin = new System.Windows.Forms.Padding(5);
            this.buttonShowAnswer.Name = "buttonShowAnswer";
            this.buttonShowAnswer.Size = new System.Drawing.Size(198, 49);
            this.buttonShowAnswer.TabIndex = 12;
            this.buttonShowAnswer.Text = "Show The Answer";
            this.buttonShowAnswer.UseVisualStyleBackColor = true;
            this.buttonShowAnswer.Click += new System.EventHandler(this.buttonShowAnswer_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 305);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 20);
            this.label8.TabIndex = 11;
            this.label8.Text = "Answer :";
            // 
            // textBoxAnswer
            // 
            this.textBoxAnswer.AcceptsReturn = true;
            this.textBoxAnswer.Enabled = false;
            this.textBoxAnswer.Font = new System.Drawing.Font("Tahoma", 14F);
            this.textBoxAnswer.Location = new System.Drawing.Point(107, 247);
            this.textBoxAnswer.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxAnswer.Multiline = true;
            this.textBoxAnswer.Name = "textBoxAnswer";
            this.textBoxAnswer.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxAnswer.Size = new System.Drawing.Size(435, 126);
            this.textBoxAnswer.TabIndex = 10;
            this.textBoxAnswer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxKeyDown);
            this.textBoxAnswer.Enter += new System.EventHandler(this.textBox_Enter);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 158);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 20);
            this.label9.TabIndex = 9;
            this.label9.Text = "Question :";
            // 
            // textBoxQuestion
            // 
            this.textBoxQuestion.AcceptsReturn = true;
            this.textBoxQuestion.Enabled = false;
            this.textBoxQuestion.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxQuestion.Location = new System.Drawing.Point(107, 105);
            this.textBoxQuestion.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxQuestion.Multiline = true;
            this.textBoxQuestion.Name = "textBoxQuestion";
            this.textBoxQuestion.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxQuestion.Size = new System.Drawing.Size(435, 126);
            this.textBoxQuestion.TabIndex = 8;
            this.textBoxQuestion.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxKeyDown);
            this.textBoxQuestion.Enter += new System.EventHandler(this.textBox_Enter);
            // 
            // labelRegDate
            // 
            this.labelRegDate.AutoSize = true;
            this.labelRegDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(101)))), ((int)(((byte)(0)))));
            this.labelRegDate.Location = new System.Drawing.Point(358, 59);
            this.labelRegDate.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelRegDate.Name = "labelRegDate";
            this.labelRegDate.Size = new System.Drawing.Size(87, 20);
            this.labelRegDate.TabIndex = 5;
            this.labelRegDate.Text = "00 / 00 / 00";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(44, 59);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(245, 20);
            this.label7.TabIndex = 4;
            this.label7.Text = "This word has been registered  in ";
            // 
            // label3Box1
            // 
            this.label3Box1.AutoSize = true;
            this.label3Box1.Location = new System.Drawing.Point(322, 18);
            this.label3Box1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3Box1.Name = "label3Box1";
            this.label3Box1.Size = new System.Drawing.Size(173, 20);
            this.label3Box1.TabIndex = 3;
            this.label3Box1.Text = "question(s) in this node";
            // 
            // label2WordsCount
            // 
            this.label2WordsCount.AutoSize = true;
            this.label2WordsCount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(83)))), ((int)(((byte)(153)))));
            this.label2WordsCount.Location = new System.Drawing.Point(215, 18);
            this.label2WordsCount.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2WordsCount.Name = "label2WordsCount";
            this.label2WordsCount.Size = new System.Drawing.Size(36, 20);
            this.label2WordsCount.TabIndex = 2;
            this.label2WordsCount.Text = "000";
            // 
            // label1Box1
            // 
            this.label1Box1.AutoSize = true;
            this.label1Box1.Location = new System.Drawing.Point(72, 18);
            this.label1Box1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1Box1.Name = "label1Box1";
            this.label1Box1.Size = new System.Drawing.Size(92, 20);
            this.label1Box1.TabIndex = 1;
            this.label1Box1.Text = "There are/is";
            // 
            // tabPageSearch
            // 
            this.tabPageSearch.Controls.Add(this.checkBoxSearchInAnswer);
            this.tabPageSearch.Controls.Add(this.checkBoxSearchInQuestion);
            this.tabPageSearch.Controls.Add(this.labelSearchMessage);
            this.tabPageSearch.Controls.Add(this.buttonSearchMoveToBox1);
            this.tabPageSearch.Controls.Add(this.buttonSearchSave);
            this.tabPageSearch.Controls.Add(this.buttonSearchDelete);
            this.tabPageSearch.Controls.Add(this.textBoxSearchAnswer);
            this.tabPageSearch.Controls.Add(this.textBoxSearchQuestion);
            this.tabPageSearch.Controls.Add(this.label1Search);
            this.tabPageSearch.Controls.Add(this.listViewSearch);
            this.tabPageSearch.Controls.Add(this.textBoxSearch);
            this.tabPageSearch.Location = new System.Drawing.Point(4, 29);
            this.tabPageSearch.Margin = new System.Windows.Forms.Padding(5);
            this.tabPageSearch.Name = "tabPageSearch";
            this.tabPageSearch.Padding = new System.Windows.Forms.Padding(5);
            this.tabPageSearch.Size = new System.Drawing.Size(607, 554);
            this.tabPageSearch.TabIndex = 2;
            this.tabPageSearch.Text = "Search";
            this.tabPageSearch.UseVisualStyleBackColor = true;
            this.tabPageSearch.Enter += new System.EventHandler(this.tabPageSearch_Enter);
            // 
            // checkBoxSearchInAnswer
            // 
            this.checkBoxSearchInAnswer.AutoSize = true;
            this.checkBoxSearchInAnswer.Checked = true;
            this.checkBoxSearchInAnswer.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxSearchInAnswer.Location = new System.Drawing.Point(410, 16);
            this.checkBoxSearchInAnswer.Margin = new System.Windows.Forms.Padding(5);
            this.checkBoxSearchInAnswer.Name = "checkBoxSearchInAnswer";
            this.checkBoxSearchInAnswer.Size = new System.Drawing.Size(89, 24);
            this.checkBoxSearchInAnswer.TabIndex = 3;
            this.checkBoxSearchInAnswer.Text = "Answers";
            this.checkBoxSearchInAnswer.UseVisualStyleBackColor = true;
            // 
            // checkBoxSearchInQuestion
            // 
            this.checkBoxSearchInQuestion.AutoSize = true;
            this.checkBoxSearchInQuestion.Checked = true;
            this.checkBoxSearchInQuestion.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxSearchInQuestion.Location = new System.Drawing.Point(232, 16);
            this.checkBoxSearchInQuestion.Margin = new System.Windows.Forms.Padding(5);
            this.checkBoxSearchInQuestion.Name = "checkBoxSearchInQuestion";
            this.checkBoxSearchInQuestion.Size = new System.Drawing.Size(100, 24);
            this.checkBoxSearchInQuestion.TabIndex = 2;
            this.checkBoxSearchInQuestion.Text = "Questions";
            this.checkBoxSearchInQuestion.UseVisualStyleBackColor = true;
            // 
            // labelSearchMessage
            // 
            this.labelSearchMessage.AutoSize = true;
            this.labelSearchMessage.ForeColor = System.Drawing.Color.Green;
            this.labelSearchMessage.Location = new System.Drawing.Point(10, 530);
            this.labelSearchMessage.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelSearchMessage.Name = "labelSearchMessage";
            this.labelSearchMessage.Size = new System.Drawing.Size(51, 20);
            this.labelSearchMessage.TabIndex = 22;
            this.labelSearchMessage.Text = "label1";
            // 
            // buttonSearchMoveToBox1
            // 
            this.buttonSearchMoveToBox1.Enabled = false;
            this.buttonSearchMoveToBox1.Location = new System.Drawing.Point(214, 483);
            this.buttonSearchMoveToBox1.Margin = new System.Windows.Forms.Padding(5);
            this.buttonSearchMoveToBox1.Name = "buttonSearchMoveToBox1";
            this.buttonSearchMoveToBox1.Size = new System.Drawing.Size(173, 39);
            this.buttonSearchMoveToBox1.TabIndex = 9;
            this.buttonSearchMoveToBox1.Text = "Move to Box1";
            this.buttonSearchMoveToBox1.UseVisualStyleBackColor = true;
            this.buttonSearchMoveToBox1.Click += new System.EventHandler(this.buttonSearchMoveToBox1_Click);
            // 
            // buttonSearchSave
            // 
            this.buttonSearchSave.Enabled = false;
            this.buttonSearchSave.Location = new System.Drawing.Point(18, 483);
            this.buttonSearchSave.Margin = new System.Windows.Forms.Padding(5);
            this.buttonSearchSave.Name = "buttonSearchSave";
            this.buttonSearchSave.Size = new System.Drawing.Size(145, 39);
            this.buttonSearchSave.TabIndex = 8;
            this.buttonSearchSave.Text = "Save this word";
            this.buttonSearchSave.UseVisualStyleBackColor = true;
            this.buttonSearchSave.Click += new System.EventHandler(this.buttonSearchSave_Click);
            // 
            // buttonSearchDelete
            // 
            this.buttonSearchDelete.Enabled = false;
            this.buttonSearchDelete.Location = new System.Drawing.Point(445, 483);
            this.buttonSearchDelete.Margin = new System.Windows.Forms.Padding(5);
            this.buttonSearchDelete.Name = "buttonSearchDelete";
            this.buttonSearchDelete.Size = new System.Drawing.Size(143, 39);
            this.buttonSearchDelete.TabIndex = 10;
            this.buttonSearchDelete.Text = "Delete this word";
            this.buttonSearchDelete.UseVisualStyleBackColor = true;
            this.buttonSearchDelete.Click += new System.EventHandler(this.buttonSearchDelete_Click);
            // 
            // textBoxSearchAnswer
            // 
            this.textBoxSearchAnswer.AcceptsReturn = true;
            this.textBoxSearchAnswer.Enabled = false;
            this.textBoxSearchAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSearchAnswer.Location = new System.Drawing.Point(307, 333);
            this.textBoxSearchAnswer.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxSearchAnswer.Multiline = true;
            this.textBoxSearchAnswer.Name = "textBoxSearchAnswer";
            this.textBoxSearchAnswer.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxSearchAnswer.Size = new System.Drawing.Size(281, 141);
            this.textBoxSearchAnswer.TabIndex = 7;
            this.textBoxSearchAnswer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxKeyDown);
            this.textBoxSearchAnswer.Enter += new System.EventHandler(this.textBox_Enter);
            // 
            // textBoxSearchQuestion
            // 
            this.textBoxSearchQuestion.AcceptsReturn = true;
            this.textBoxSearchQuestion.Enabled = false;
            this.textBoxSearchQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSearchQuestion.Location = new System.Drawing.Point(19, 333);
            this.textBoxSearchQuestion.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxSearchQuestion.Multiline = true;
            this.textBoxSearchQuestion.Name = "textBoxSearchQuestion";
            this.textBoxSearchQuestion.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxSearchQuestion.Size = new System.Drawing.Size(279, 141);
            this.textBoxSearchQuestion.TabIndex = 6;
            this.textBoxSearchQuestion.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxKeyDown);
            this.textBoxSearchQuestion.Enter += new System.EventHandler(this.textBox_Enter);
            // 
            // label1Search
            // 
            this.label1Search.AutoSize = true;
            this.label1Search.Location = new System.Drawing.Point(87, 16);
            this.label1Search.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1Search.Name = "label1Search";
            this.label1Search.Size = new System.Drawing.Size(88, 20);
            this.label1Search.TabIndex = 0;
            this.label1Search.Text = "Search in : ";
            // 
            // listViewSearch
            // 
            this.listViewSearch.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.QuestionColumn,
            this.AnswerColumn,
            this.DateColumn});
            this.listViewSearch.FullRowSelect = true;
            this.listViewSearch.GridLines = true;
            this.listViewSearch.HideSelection = false;
            this.listViewSearch.Location = new System.Drawing.Point(19, 76);
            this.listViewSearch.Margin = new System.Windows.Forms.Padding(5);
            this.listViewSearch.Name = "listViewSearch";
            this.listViewSearch.Size = new System.Drawing.Size(569, 247);
            this.listViewSearch.TabIndex = 5;
            this.listViewSearch.UseCompatibleStateImageBehavior = false;
            this.listViewSearch.View = System.Windows.Forms.View.Details;
            this.listViewSearch.SelectedIndexChanged += new System.EventHandler(this.listViewSearch_SelectedIndexChanged);
            // 
            // QuestionColumn
            // 
            this.QuestionColumn.Text = "Question";
            this.QuestionColumn.Width = 178;
            // 
            // AnswerColumn
            // 
            this.AnswerColumn.Text = "Answer";
            this.AnswerColumn.Width = 158;
            // 
            // DateColumn
            // 
            this.DateColumn.Text = "Date";
            this.DateColumn.Width = 156;
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(19, 47);
            this.textBoxSearch.Margin = new System.Windows.Forms.Padding(5);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(569, 26);
            this.textBoxSearch.TabIndex = 4;
            this.textBoxSearch.TextChanged += new System.EventHandler(this.textBoxSearch_TextChanged);
            this.textBoxSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxKeyDown);
            // 
            // tabPageStatistics
            // 
            this.tabPageStatistics.Controls.Add(this.label10);
            this.tabPageStatistics.Controls.Add(this.labelAllWords);
            this.tabPageStatistics.Controls.Add(this.label20Statistics);
            this.tabPageStatistics.Controls.Add(this.labelStatisticsDate);
            this.tabPageStatistics.Controls.Add(this.label19Statistics);
            this.tabPageStatistics.Controls.Add(this.label18Statistics);
            this.tabPageStatistics.Controls.Add(this.labelStatisticsDataBase);
            this.tabPageStatistics.Controls.Add(this.label16Statistics);
            this.tabPageStatistics.Controls.Add(this.label15Statistics);
            this.tabPageStatistics.Controls.Add(this.labelStatisticsBox5);
            this.tabPageStatistics.Controls.Add(this.label13Statistics);
            this.tabPageStatistics.Controls.Add(this.label12Statistics);
            this.tabPageStatistics.Controls.Add(this.labelStatisticsBox4);
            this.tabPageStatistics.Controls.Add(this.label10Statistics);
            this.tabPageStatistics.Controls.Add(this.label9Statistics);
            this.tabPageStatistics.Controls.Add(this.labelStatisticsBox3);
            this.tabPageStatistics.Controls.Add(this.label7Statistics);
            this.tabPageStatistics.Controls.Add(this.label6Statistics);
            this.tabPageStatistics.Controls.Add(this.labelStatisticsBox2);
            this.tabPageStatistics.Controls.Add(this.label4Statistics);
            this.tabPageStatistics.Controls.Add(this.label3Statistics);
            this.tabPageStatistics.Controls.Add(this.labelStatisticsBox1);
            this.tabPageStatistics.Controls.Add(this.label1Statistics);
            this.tabPageStatistics.Location = new System.Drawing.Point(4, 29);
            this.tabPageStatistics.Margin = new System.Windows.Forms.Padding(5);
            this.tabPageStatistics.Name = "tabPageStatistics";
            this.tabPageStatistics.Padding = new System.Windows.Forms.Padding(5);
            this.tabPageStatistics.Size = new System.Drawing.Size(607, 554);
            this.tabPageStatistics.TabIndex = 3;
            this.tabPageStatistics.Text = "Statistics";
            this.tabPageStatistics.UseVisualStyleBackColor = true;
            this.tabPageStatistics.Enter += new System.EventHandler(this.tabPageStatistics_Enter);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(395, 400);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 20);
            this.label10.TabIndex = 42;
            this.label10.Text = "word(s)";
            // 
            // labelAllWords
            // 
            this.labelAllWords.AutoSize = true;
            this.labelAllWords.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.labelAllWords.ForeColor = System.Drawing.Color.Black;
            this.labelAllWords.Location = new System.Drawing.Point(269, 400);
            this.labelAllWords.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelAllWords.Name = "labelAllWords";
            this.labelAllWords.Size = new System.Drawing.Size(36, 20);
            this.labelAllWords.TabIndex = 41;
            this.labelAllWords.Text = "000";
            // 
            // label20Statistics
            // 
            this.label20Statistics.AutoSize = true;
            this.label20Statistics.Location = new System.Drawing.Point(148, 400);
            this.label20Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label20Statistics.Name = "label20Statistics";
            this.label20Statistics.Size = new System.Drawing.Size(80, 20);
            this.label20Statistics.TabIndex = 40;
            this.label20Statistics.Text = "All words :";
            // 
            // labelStatisticsDate
            // 
            this.labelStatisticsDate.AutoSize = true;
            this.labelStatisticsDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(83)))), ((int)(((byte)(153)))));
            this.labelStatisticsDate.Location = new System.Drawing.Point(363, 471);
            this.labelStatisticsDate.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelStatisticsDate.Name = "labelStatisticsDate";
            this.labelStatisticsDate.Size = new System.Drawing.Size(87, 20);
            this.labelStatisticsDate.TabIndex = 39;
            this.labelStatisticsDate.Text = "00 / 00 / 00";
            // 
            // label19Statistics
            // 
            this.label19Statistics.AutoSize = true;
            this.label19Statistics.Location = new System.Drawing.Point(69, 471);
            this.label19Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label19Statistics.Name = "label19Statistics";
            this.label19Statistics.Size = new System.Drawing.Size(262, 20);
            this.label19Statistics.TabIndex = 38;
            this.label19Statistics.Text = "This DataBase has been created in ";
            // 
            // label18Statistics
            // 
            this.label18Statistics.AutoSize = true;
            this.label18Statistics.Location = new System.Drawing.Point(395, 339);
            this.label18Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label18Statistics.Name = "label18Statistics";
            this.label18Statistics.Size = new System.Drawing.Size(61, 20);
            this.label18Statistics.TabIndex = 37;
            this.label18Statistics.Text = "word(s)";
            // 
            // labelStatisticsDataBase
            // 
            this.labelStatisticsDataBase.AutoSize = true;
            this.labelStatisticsDataBase.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(83)))), ((int)(((byte)(153)))));
            this.labelStatisticsDataBase.Location = new System.Drawing.Point(269, 339);
            this.labelStatisticsDataBase.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelStatisticsDataBase.Name = "labelStatisticsDataBase";
            this.labelStatisticsDataBase.Size = new System.Drawing.Size(36, 20);
            this.labelStatisticsDataBase.TabIndex = 36;
            this.labelStatisticsDataBase.Text = "000";
            // 
            // label16Statistics
            // 
            this.label16Statistics.AutoSize = true;
            this.label16Statistics.Location = new System.Drawing.Point(134, 339);
            this.label16Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label16Statistics.Name = "label16Statistics";
            this.label16Statistics.Size = new System.Drawing.Size(93, 20);
            this.label16Statistics.TabIndex = 35;
            this.label16Statistics.Text = "Data Base :";
            // 
            // label15Statistics
            // 
            this.label15Statistics.AutoSize = true;
            this.label15Statistics.Location = new System.Drawing.Point(395, 280);
            this.label15Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label15Statistics.Name = "label15Statistics";
            this.label15Statistics.Size = new System.Drawing.Size(61, 20);
            this.label15Statistics.TabIndex = 34;
            this.label15Statistics.Text = "word(s)";
            // 
            // labelStatisticsBox5
            // 
            this.labelStatisticsBox5.AutoSize = true;
            this.labelStatisticsBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(233)))), ((int)(((byte)(216)))));
            this.labelStatisticsBox5.Location = new System.Drawing.Point(269, 280);
            this.labelStatisticsBox5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelStatisticsBox5.Name = "labelStatisticsBox5";
            this.labelStatisticsBox5.Size = new System.Drawing.Size(36, 20);
            this.labelStatisticsBox5.TabIndex = 33;
            this.labelStatisticsBox5.Text = "000";
            // 
            // label13Statistics
            // 
            this.label13Statistics.AutoSize = true;
            this.label13Statistics.Location = new System.Drawing.Point(183, 280);
            this.label13Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label13Statistics.Name = "label13Statistics";
            this.label13Statistics.Size = new System.Drawing.Size(57, 20);
            this.label13Statistics.TabIndex = 32;
            this.label13Statistics.Text = "Box5 : ";
            // 
            // label12Statistics
            // 
            this.label12Statistics.AutoSize = true;
            this.label12Statistics.Location = new System.Drawing.Point(395, 218);
            this.label12Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label12Statistics.Name = "label12Statistics";
            this.label12Statistics.Size = new System.Drawing.Size(61, 20);
            this.label12Statistics.TabIndex = 31;
            this.label12Statistics.Text = "word(s)";
            // 
            // labelStatisticsBox4
            // 
            this.labelStatisticsBox4.AutoSize = true;
            this.labelStatisticsBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(197)))), ((int)(((byte)(166)))));
            this.labelStatisticsBox4.Location = new System.Drawing.Point(269, 218);
            this.labelStatisticsBox4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelStatisticsBox4.Name = "labelStatisticsBox4";
            this.labelStatisticsBox4.Size = new System.Drawing.Size(36, 20);
            this.labelStatisticsBox4.TabIndex = 30;
            this.labelStatisticsBox4.Text = "000";
            // 
            // label10Statistics
            // 
            this.label10Statistics.AutoSize = true;
            this.label10Statistics.Location = new System.Drawing.Point(183, 218);
            this.label10Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10Statistics.Name = "label10Statistics";
            this.label10Statistics.Size = new System.Drawing.Size(57, 20);
            this.label10Statistics.TabIndex = 29;
            this.label10Statistics.Text = "Box4 : ";
            // 
            // label9Statistics
            // 
            this.label9Statistics.AutoSize = true;
            this.label9Statistics.Location = new System.Drawing.Point(395, 158);
            this.label9Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9Statistics.Name = "label9Statistics";
            this.label9Statistics.Size = new System.Drawing.Size(61, 20);
            this.label9Statistics.TabIndex = 28;
            this.label9Statistics.Text = "word(s)";
            // 
            // labelStatisticsBox3
            // 
            this.labelStatisticsBox3.AutoSize = true;
            this.labelStatisticsBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(200)))), ((int)(((byte)(184)))));
            this.labelStatisticsBox3.Location = new System.Drawing.Point(269, 158);
            this.labelStatisticsBox3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelStatisticsBox3.Name = "labelStatisticsBox3";
            this.labelStatisticsBox3.Size = new System.Drawing.Size(36, 20);
            this.labelStatisticsBox3.TabIndex = 27;
            this.labelStatisticsBox3.Text = "000";
            // 
            // label7Statistics
            // 
            this.label7Statistics.AutoSize = true;
            this.label7Statistics.Location = new System.Drawing.Point(183, 158);
            this.label7Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7Statistics.Name = "label7Statistics";
            this.label7Statistics.Size = new System.Drawing.Size(57, 20);
            this.label7Statistics.TabIndex = 26;
            this.label7Statistics.Text = "Box3 : ";
            // 
            // label6Statistics
            // 
            this.label6Statistics.AutoSize = true;
            this.label6Statistics.Location = new System.Drawing.Point(395, 99);
            this.label6Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6Statistics.Name = "label6Statistics";
            this.label6Statistics.Size = new System.Drawing.Size(61, 20);
            this.label6Statistics.TabIndex = 25;
            this.label6Statistics.Text = "word(s)";
            // 
            // labelStatisticsBox2
            // 
            this.labelStatisticsBox2.AutoSize = true;
            this.labelStatisticsBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(210)))));
            this.labelStatisticsBox2.Location = new System.Drawing.Point(269, 99);
            this.labelStatisticsBox2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelStatisticsBox2.Name = "labelStatisticsBox2";
            this.labelStatisticsBox2.Size = new System.Drawing.Size(36, 20);
            this.labelStatisticsBox2.TabIndex = 24;
            this.labelStatisticsBox2.Text = "000";
            // 
            // label4Statistics
            // 
            this.label4Statistics.AutoSize = true;
            this.label4Statistics.Location = new System.Drawing.Point(183, 99);
            this.label4Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4Statistics.Name = "label4Statistics";
            this.label4Statistics.Size = new System.Drawing.Size(57, 20);
            this.label4Statistics.TabIndex = 23;
            this.label4Statistics.Text = "Box2 : ";
            // 
            // label3Statistics
            // 
            this.label3Statistics.AutoSize = true;
            this.label3Statistics.Location = new System.Drawing.Point(395, 37);
            this.label3Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3Statistics.Name = "label3Statistics";
            this.label3Statistics.Size = new System.Drawing.Size(61, 20);
            this.label3Statistics.TabIndex = 22;
            this.label3Statistics.Text = "word(s)";
            // 
            // labelStatisticsBox1
            // 
            this.labelStatisticsBox1.AutoSize = true;
            this.labelStatisticsBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.labelStatisticsBox1.Location = new System.Drawing.Point(269, 37);
            this.labelStatisticsBox1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelStatisticsBox1.Name = "labelStatisticsBox1";
            this.labelStatisticsBox1.Size = new System.Drawing.Size(36, 20);
            this.labelStatisticsBox1.TabIndex = 21;
            this.labelStatisticsBox1.Text = "000";
            // 
            // label1Statistics
            // 
            this.label1Statistics.AutoSize = true;
            this.label1Statistics.Location = new System.Drawing.Point(183, 37);
            this.label1Statistics.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1Statistics.Name = "label1Statistics";
            this.label1Statistics.Size = new System.Drawing.Size(57, 20);
            this.label1Statistics.TabIndex = 20;
            this.label1Statistics.Text = "Box1 : ";
            // 
            // columnHeaderQuestion
            // 
            this.columnHeaderQuestion.Text = "Question";
            this.columnHeaderQuestion.Width = 130;
            // 
            // columnHeaderAnswer
            // 
            this.columnHeaderAnswer.Text = "Answer";
            this.columnHeaderAnswer.Width = 130;
            // 
            // columnHeaderDate
            // 
            this.columnHeaderDate.Text = "Date";
            this.columnHeaderDate.Width = 70;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemDelete,
            this.toolStripSeparator2,
            this.ToolStripMenuItemShiftUp,
            this.toolStripSeparator3,
            this.ToolStripMenuItemMoveTo,
            this.ToolStripMenuItemExport});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(142, 104);
            // 
            // ToolStripMenuItemDelete
            // 
            this.ToolStripMenuItemDelete.Enabled = false;
            this.ToolStripMenuItemDelete.Image = global::Leitner_Box.Properties.Resources.delete;
            this.ToolStripMenuItemDelete.Name = "ToolStripMenuItemDelete";
            this.ToolStripMenuItemDelete.Size = new System.Drawing.Size(141, 22);
            this.ToolStripMenuItemDelete.Text = "Delete ( Del )";
            this.ToolStripMenuItemDelete.Click += new System.EventHandler(this.toolStripMenuItemDelete_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(138, 6);
            // 
            // ToolStripMenuItemShiftUp
            // 
            this.ToolStripMenuItemShiftUp.Enabled = false;
            this.ToolStripMenuItemShiftUp.Image = global::Leitner_Box.Properties.Resources.shift;
            this.ToolStripMenuItemShiftUp.Name = "ToolStripMenuItemShiftUp";
            this.ToolStripMenuItemShiftUp.Size = new System.Drawing.Size(141, 22);
            this.ToolStripMenuItemShiftUp.Text = "Shift up";
            this.ToolStripMenuItemShiftUp.Click += new System.EventHandler(this.toolStripMenuItemShiftUp_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(138, 6);
            // 
            // ToolStripMenuItemMoveTo
            // 
            this.ToolStripMenuItemMoveTo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemBox1,
            this.ToolStripMenuItemBox2,
            this.ToolStripMenuItemBox3,
            this.ToolStripMenuItemBox4,
            this.ToolStripMenuItemBox5,
            this.ToolStripMenuItemDataBase});
            this.ToolStripMenuItemMoveTo.Enabled = false;
            this.ToolStripMenuItemMoveTo.Name = "ToolStripMenuItemMoveTo";
            this.ToolStripMenuItemMoveTo.Size = new System.Drawing.Size(141, 22);
            this.ToolStripMenuItemMoveTo.Text = "Move to";
            // 
            // ToolStripMenuItemBox1
            // 
            this.ToolStripMenuItemBox1.Name = "ToolStripMenuItemBox1";
            this.ToolStripMenuItemBox1.Size = new System.Drawing.Size(125, 22);
            this.ToolStripMenuItemBox1.Text = "Box 1";
            this.ToolStripMenuItemBox1.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox2
            // 
            this.ToolStripMenuItemBox2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemBox2Part1,
            this.ToolStripMenuItemBox2Part2});
            this.ToolStripMenuItemBox2.Name = "ToolStripMenuItemBox2";
            this.ToolStripMenuItemBox2.Size = new System.Drawing.Size(125, 22);
            this.ToolStripMenuItemBox2.Text = "Box 2";
            // 
            // ToolStripMenuItemBox2Part1
            // 
            this.ToolStripMenuItemBox2Part1.Name = "ToolStripMenuItemBox2Part1";
            this.ToolStripMenuItemBox2Part1.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox2Part1.Text = "Part 1";
            this.ToolStripMenuItemBox2Part1.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox2Part2
            // 
            this.ToolStripMenuItemBox2Part2.Name = "ToolStripMenuItemBox2Part2";
            this.ToolStripMenuItemBox2Part2.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox2Part2.Text = "Part 2";
            this.ToolStripMenuItemBox2Part2.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox3
            // 
            this.ToolStripMenuItemBox3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemBox3Part1,
            this.ToolStripMenuItemBox3Part2,
            this.ToolStripMenuItemBox3Part3,
            this.ToolStripMenuItemBox3Part4,
            this.ToolStripMenuItemBox3Part5});
            this.ToolStripMenuItemBox3.Name = "ToolStripMenuItemBox3";
            this.ToolStripMenuItemBox3.Size = new System.Drawing.Size(125, 22);
            this.ToolStripMenuItemBox3.Text = "Box 3";
            // 
            // ToolStripMenuItemBox3Part1
            // 
            this.ToolStripMenuItemBox3Part1.Name = "ToolStripMenuItemBox3Part1";
            this.ToolStripMenuItemBox3Part1.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox3Part1.Text = "Part 1";
            this.ToolStripMenuItemBox3Part1.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox3Part2
            // 
            this.ToolStripMenuItemBox3Part2.Name = "ToolStripMenuItemBox3Part2";
            this.ToolStripMenuItemBox3Part2.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox3Part2.Text = "Part 2";
            this.ToolStripMenuItemBox3Part2.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox3Part3
            // 
            this.ToolStripMenuItemBox3Part3.Name = "ToolStripMenuItemBox3Part3";
            this.ToolStripMenuItemBox3Part3.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox3Part3.Text = "Part 3";
            this.ToolStripMenuItemBox3Part3.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox3Part4
            // 
            this.ToolStripMenuItemBox3Part4.Name = "ToolStripMenuItemBox3Part4";
            this.ToolStripMenuItemBox3Part4.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox3Part4.Text = "Part 4";
            this.ToolStripMenuItemBox3Part4.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox3Part5
            // 
            this.ToolStripMenuItemBox3Part5.Name = "ToolStripMenuItemBox3Part5";
            this.ToolStripMenuItemBox3Part5.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox3Part5.Text = "Part 5";
            this.ToolStripMenuItemBox3Part5.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox4
            // 
            this.ToolStripMenuItemBox4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemBox4Part1,
            this.ToolStripMenuItemBox4Part2,
            this.ToolStripMenuItemBox4Part3,
            this.ToolStripMenuItemBox4Part4,
            this.ToolStripMenuItemBox4Part5,
            this.ToolStripMenuItemBox4Part6,
            this.ToolStripMenuItemBox4Part7,
            this.ToolStripMenuItemBox4Part8});
            this.ToolStripMenuItemBox4.Name = "ToolStripMenuItemBox4";
            this.ToolStripMenuItemBox4.Size = new System.Drawing.Size(125, 22);
            this.ToolStripMenuItemBox4.Text = "Box 4";
            // 
            // ToolStripMenuItemBox4Part1
            // 
            this.ToolStripMenuItemBox4Part1.Name = "ToolStripMenuItemBox4Part1";
            this.ToolStripMenuItemBox4Part1.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox4Part1.Text = "Part 1";
            this.ToolStripMenuItemBox4Part1.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox4Part2
            // 
            this.ToolStripMenuItemBox4Part2.Name = "ToolStripMenuItemBox4Part2";
            this.ToolStripMenuItemBox4Part2.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox4Part2.Text = "Part 2";
            this.ToolStripMenuItemBox4Part2.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox4Part3
            // 
            this.ToolStripMenuItemBox4Part3.Name = "ToolStripMenuItemBox4Part3";
            this.ToolStripMenuItemBox4Part3.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox4Part3.Text = "Part 3";
            this.ToolStripMenuItemBox4Part3.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox4Part4
            // 
            this.ToolStripMenuItemBox4Part4.Name = "ToolStripMenuItemBox4Part4";
            this.ToolStripMenuItemBox4Part4.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox4Part4.Text = "Part 4";
            this.ToolStripMenuItemBox4Part4.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox4Part5
            // 
            this.ToolStripMenuItemBox4Part5.Name = "ToolStripMenuItemBox4Part5";
            this.ToolStripMenuItemBox4Part5.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox4Part5.Text = "Part 5";
            this.ToolStripMenuItemBox4Part5.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox4Part6
            // 
            this.ToolStripMenuItemBox4Part6.Name = "ToolStripMenuItemBox4Part6";
            this.ToolStripMenuItemBox4Part6.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox4Part6.Text = "Part 6";
            this.ToolStripMenuItemBox4Part6.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox4Part7
            // 
            this.ToolStripMenuItemBox4Part7.Name = "ToolStripMenuItemBox4Part7";
            this.ToolStripMenuItemBox4Part7.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox4Part7.Text = "Part 7";
            this.ToolStripMenuItemBox4Part7.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox4Part8
            // 
            this.ToolStripMenuItemBox4Part8.Name = "ToolStripMenuItemBox4Part8";
            this.ToolStripMenuItemBox4Part8.Size = new System.Drawing.Size(104, 22);
            this.ToolStripMenuItemBox4Part8.Text = "Part 8";
            this.ToolStripMenuItemBox4Part8.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5
            // 
            this.ToolStripMenuItemBox5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemBox5Part1,
            this.ToolStripMenuItemBox5Part2,
            this.ToolStripMenuItemBox5Part3,
            this.ToolStripMenuItemBox5Part4,
            this.ToolStripMenuItemBox5Part5,
            this.ToolStripMenuItemBox5Part6,
            this.ToolStripMenuItemBox5Part7,
            this.ToolStripMenuItemBox5Part8,
            this.ToolStripMenuItemBox5Part9,
            this.ToolStripMenuItemBox5Part10,
            this.ToolStripMenuItemBox5Part11,
            this.ToolStripMenuItemBox5Part12,
            this.ToolStripMenuItemBox5Part13,
            this.ToolStripMenuItemBox5Part14});
            this.ToolStripMenuItemBox5.Name = "ToolStripMenuItemBox5";
            this.ToolStripMenuItemBox5.Size = new System.Drawing.Size(125, 22);
            this.ToolStripMenuItemBox5.Text = "Box 5";
            // 
            // ToolStripMenuItemBox5Part1
            // 
            this.ToolStripMenuItemBox5Part1.Name = "ToolStripMenuItemBox5Part1";
            this.ToolStripMenuItemBox5Part1.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part1.Text = "Part 1";
            this.ToolStripMenuItemBox5Part1.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part2
            // 
            this.ToolStripMenuItemBox5Part2.Name = "ToolStripMenuItemBox5Part2";
            this.ToolStripMenuItemBox5Part2.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part2.Text = "Part 2";
            this.ToolStripMenuItemBox5Part2.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part3
            // 
            this.ToolStripMenuItemBox5Part3.Name = "ToolStripMenuItemBox5Part3";
            this.ToolStripMenuItemBox5Part3.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part3.Text = "Part 3";
            this.ToolStripMenuItemBox5Part3.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part4
            // 
            this.ToolStripMenuItemBox5Part4.Name = "ToolStripMenuItemBox5Part4";
            this.ToolStripMenuItemBox5Part4.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part4.Text = "Part 4";
            this.ToolStripMenuItemBox5Part4.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part5
            // 
            this.ToolStripMenuItemBox5Part5.Name = "ToolStripMenuItemBox5Part5";
            this.ToolStripMenuItemBox5Part5.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part5.Text = "Part 5";
            this.ToolStripMenuItemBox5Part5.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part6
            // 
            this.ToolStripMenuItemBox5Part6.Name = "ToolStripMenuItemBox5Part6";
            this.ToolStripMenuItemBox5Part6.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part6.Text = "Part 6";
            this.ToolStripMenuItemBox5Part6.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part7
            // 
            this.ToolStripMenuItemBox5Part7.Name = "ToolStripMenuItemBox5Part7";
            this.ToolStripMenuItemBox5Part7.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part7.Text = "Part 7";
            this.ToolStripMenuItemBox5Part7.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part8
            // 
            this.ToolStripMenuItemBox5Part8.Name = "ToolStripMenuItemBox5Part8";
            this.ToolStripMenuItemBox5Part8.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part8.Text = "Part 8";
            this.ToolStripMenuItemBox5Part8.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part9
            // 
            this.ToolStripMenuItemBox5Part9.Name = "ToolStripMenuItemBox5Part9";
            this.ToolStripMenuItemBox5Part9.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part9.Text = "Part 9";
            this.ToolStripMenuItemBox5Part9.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part10
            // 
            this.ToolStripMenuItemBox5Part10.Name = "ToolStripMenuItemBox5Part10";
            this.ToolStripMenuItemBox5Part10.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part10.Text = "Part 10";
            this.ToolStripMenuItemBox5Part10.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part11
            // 
            this.ToolStripMenuItemBox5Part11.Name = "ToolStripMenuItemBox5Part11";
            this.ToolStripMenuItemBox5Part11.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part11.Text = "Part 11";
            this.ToolStripMenuItemBox5Part11.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part12
            // 
            this.ToolStripMenuItemBox5Part12.Name = "ToolStripMenuItemBox5Part12";
            this.ToolStripMenuItemBox5Part12.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part12.Text = "Part 12";
            this.ToolStripMenuItemBox5Part12.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part13
            // 
            this.ToolStripMenuItemBox5Part13.Name = "ToolStripMenuItemBox5Part13";
            this.ToolStripMenuItemBox5Part13.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part13.Text = "Part 13";
            this.ToolStripMenuItemBox5Part13.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemBox5Part14
            // 
            this.ToolStripMenuItemBox5Part14.Name = "ToolStripMenuItemBox5Part14";
            this.ToolStripMenuItemBox5Part14.Size = new System.Drawing.Size(110, 22);
            this.ToolStripMenuItemBox5Part14.Text = "Part 14";
            this.ToolStripMenuItemBox5Part14.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemDataBase
            // 
            this.ToolStripMenuItemDataBase.Name = "ToolStripMenuItemDataBase";
            this.ToolStripMenuItemDataBase.Size = new System.Drawing.Size(125, 22);
            this.ToolStripMenuItemDataBase.Text = "Data Base";
            this.ToolStripMenuItemDataBase.Click += new System.EventHandler(this.ToolStripMenuItemMoveTo_Click);
            // 
            // ToolStripMenuItemExport
            // 
            this.ToolStripMenuItemExport.Enabled = false;
            this.ToolStripMenuItemExport.Image = global::Leitner_Box.Properties.Resources.export;
            this.ToolStripMenuItemExport.Name = "ToolStripMenuItemExport";
            this.ToolStripMenuItemExport.Size = new System.Drawing.Size(141, 22);
            this.ToolStripMenuItemExport.Text = "Export";
            this.ToolStripMenuItemExport.Click += new System.EventHandler(this.toolStripMenuItemExport_Click);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "Html file|*.htm";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Question";
            this.columnHeader1.Width = 130;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Answer";
            this.columnHeader2.Width = 130;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Date";
            this.columnHeader3.Width = 130;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(881, 643);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Leitner Box";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPageAddQuestions.ResumeLayout(false);
            this.tabPageAddQuestions.PerformLayout();
            this.tabPageExplorer.ResumeLayout(false);
            this.tabPageExplorer.PerformLayout();
            this.tabPageSearch.ResumeLayout(false);
            this.tabPageSearch.PerformLayout();
            this.tabPageStatistics.ResumeLayout(false);
            this.tabPageStatistics.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageAddQuestions;
        private System.Windows.Forms.TabPage tabPageExplorer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxNewAnswer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxNewQuestion;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.TabPage tabPageSearch;
        private System.Windows.Forms.ToolStripMenuItem settingToolStripMenuItem;
        private System.Windows.Forms.Label labelRegDate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3Box1;
        private System.Windows.Forms.Label label2WordsCount;
        private System.Windows.Forms.Label label1Box1;
        private System.Windows.Forms.ToolStripMenuItem questionTextboxesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemRightToLeftQuestion;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemLeftToRightQuestion;
        private System.Windows.Forms.ToolStripMenuItem answerTextboxesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemRightToLeftAnswer;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemLeftToRightAnswer;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem dateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemChristianDate;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemPersianDate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxAnswer;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxQuestion;
        private System.Windows.Forms.TabPage tabPageStatistics;
        private System.Windows.Forms.Label labelStatisticsDate;
        private System.Windows.Forms.Label label19Statistics;
        private System.Windows.Forms.Label label18Statistics;
        private System.Windows.Forms.Label labelStatisticsDataBase;
        private System.Windows.Forms.Label label16Statistics;
        private System.Windows.Forms.Label label15Statistics;
        private System.Windows.Forms.Label labelStatisticsBox5;
        private System.Windows.Forms.Label label13Statistics;
        private System.Windows.Forms.Label label12Statistics;
        private System.Windows.Forms.Label labelStatisticsBox4;
        private System.Windows.Forms.Label label10Statistics;
        private System.Windows.Forms.Label label9Statistics;
        private System.Windows.Forms.Label labelStatisticsBox3;
        private System.Windows.Forms.Label label7Statistics;
        private System.Windows.Forms.Label label6Statistics;
        private System.Windows.Forms.Label labelStatisticsBox2;
        private System.Windows.Forms.Label label4Statistics;
        private System.Windows.Forms.Label label3Statistics;
        private System.Windows.Forms.Label labelStatisticsBox1;
        private System.Windows.Forms.Label label1Statistics;
        private System.Windows.Forms.Button buttonSearchSave;
        private System.Windows.Forms.Button buttonSearchDelete;
        private System.Windows.Forms.TextBox textBoxSearchAnswer;
        private System.Windows.Forms.TextBox textBoxSearchQuestion;
        private System.Windows.Forms.Label label1Search;
        private System.Windows.Forms.ListView listViewSearch;
        private System.Windows.Forms.ColumnHeader QuestionColumn;
        private System.Windows.Forms.ColumnHeader AnswerColumn;
        private System.Windows.Forms.ColumnHeader DateColumn;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.ColumnHeader columnHeaderQuestion;
        private System.Windows.Forms.ColumnHeader columnHeaderAnswer;
        private System.Windows.Forms.ColumnHeader columnHeaderDate;
        private System.Windows.Forms.Button buttonFalse;
        private System.Windows.Forms.Button buttonTrue;
        private System.Windows.Forms.Button buttonShowAnswer;
        private System.Windows.Forms.Label labelAddQuestionMessage;
        private System.Windows.Forms.Label labelNewWordDate;
        private System.Windows.Forms.Button buttonDelete1;
        private System.Windows.Forms.Button buttonSave1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelPartID;
        private System.Windows.Forms.Label labelBoxID;
        private System.Windows.Forms.Label labelAnswerToQuestionMessage;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optimizeXmlFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Button buttonSearchMoveToBox1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemDelete;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemShiftUp;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemExport;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem exportAllWordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemAboutMe;
        private System.Windows.Forms.ToolStripMenuItem usersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemCreateNewUser;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemSelectUser;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelAllWords;
        private System.Windows.Forms.Label label20Statistics;
        private System.Windows.Forms.Label labelSearchMessage;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemMoveTo;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox2;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox2Part1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox2Part2;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox3;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox3Part1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox3Part2;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox3Part3;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox3Part4;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox3Part5;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox4;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox4Part1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox4Part2;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox4Part3;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox4Part4;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox4Part5;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox4Part6;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox4Part7;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemDataBase;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox4Part8;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part2;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part3;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part4;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part5;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part6;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part7;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part8;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part9;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part10;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part11;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part12;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part13;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBox5Part14;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.CheckBox checkBoxSearchInAnswer;
        private System.Windows.Forms.CheckBox checkBoxSearchInQuestion;
        private System.Windows.Forms.ListBox listBoxAutoComplete;
    }
}

